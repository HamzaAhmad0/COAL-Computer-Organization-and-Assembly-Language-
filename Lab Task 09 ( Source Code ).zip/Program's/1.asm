.model small 
.data 
arr db 5,7,3

.code    

main proc
    
    mov ax, @data
    mov ds, ax
    
    mov si, offset arr
    mov dl, [si]
    add dl, 48
    
    mov ah, 2
    int 21h
    
    main endp

end main 