org 100h

    mov dx, offset msg1   ; "Enter First Number:"
    mov ah, 9
    int 21h
    mov ah, 1             ; read first digit -> AL
    int 21h
    mov cl, al            ; keep it in CL

    mov dx, offset msg2   ; "Enter Second Number:"
    mov ah, 9
    int 21h
    mov ah, 1             ; read second digit -> AL
    int 21h

    cmp al, cl            ; compare second with first
    je equal              ; ZF = 1 -> equal

    mov dx, offset msg4   ; not equal
    jmp show              ; unconditional jump: skip the equal part

equal:
    mov dx, offset msg3   ; equal

show:
    mov ah, 9             ; print whichever message DX points to
    int 21h
    ret                   ; one single exit

msg1 db 13,10, "Enter First Number: $"
msg2 db 13,10, "Enter Second Number: $"
msg3 db 13,10, "Numbers are equal.$"
msg4 db 13,10, "Numbers are not equal.$"
