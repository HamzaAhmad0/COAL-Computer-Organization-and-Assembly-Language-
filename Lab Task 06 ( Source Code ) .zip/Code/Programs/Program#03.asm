org 100h

main proc
    label1:
        mov dl, 'a'   ; character to print
        mov ah, 2     ; DOS function 2 = print a character
        int 21h       ; print 'a'
    jmp label1    ; ALWAYS go back to label1
main endp

ret
