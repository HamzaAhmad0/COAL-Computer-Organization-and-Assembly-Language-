.model small
.data
   msg1 db 10,13, "Enter First Number:$"
   msg2 db 10,13, "Enter Second Number:$"
   msg3 db 10,13, "Number are equal...$"
   msg4 db 10,13, "Number are Not equal...$"
.code
main proc
    mov ax,@data
    mov ds,ax

    mov dx,offset msg1   ; show "Enter First Number:"
    mov ah,9
    int 21h

    mov ah,1             ; read first key -> AL
    int 21h
    mov cl,al            ; save it in CL

    mov dx,offset msg2   ; show "Enter Second Number:"
    mov ah,9
    int 21h

    mov ah,1             ; read second key -> AL
    int 21h
    mov dl,al            ; save it in DL

    cmp dl,cl            ; compare second with first
    je equal             ; if equal (ZF=1) jump to equal

    mov dx,offset msg4   ; not equal: show message
    mov ah,9
    int 21h
    mov ah,4ch           ; exit program
    int 21h

    equal:
    mov dx,offset msg3   ; equal: show message
    mov ah,9
    int 21h

main endp
end main
