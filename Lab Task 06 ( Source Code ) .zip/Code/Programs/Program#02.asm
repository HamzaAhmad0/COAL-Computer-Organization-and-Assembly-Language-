org 100h

mov cx, 26        ; 26 letters in the alphabet
mov dx, 65        ; 65 = ASCII code of 'A'

test:
    mov ah, 2     ; print one character
    int 21h       ; prints the character in DL
    inc dx        ; 'A' -> 'B' -> 'C' ...
loop test         ; repeat until CX = 0

ret
