org 100h

mov cx, 10        ; repeat 10 times (10 digits)
mov dx, 48        ; 48 = ASCII code of '0'

test:
    mov ah, 2     ; DOS function 2 = print one character
    int 21h       ; prints the character in DL
    inc dx        ; next character: 48 -> 49 -> 50 ...
loop test         ; CX = CX - 1; if CX != 0, go back to test

ret               ; return / end the program
