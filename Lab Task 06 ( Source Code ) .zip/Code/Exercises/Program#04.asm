.model small
.stack 100h
.data
    msg1 db 13,10,"Enter first digit: $"
    msg2 db 13,10,"Enter second digit: $"
    msg3 db 13,10,"First is greater$"
    msg4 db 13,10,"Second is greater$"
    msg5 db 13,10,"Equal$"

.code
main proc
    mov ax, @data
    mov ds, ax

    mov dx, offset msg1
    mov ah, 9
    int 21h

    mov ah, 1
    int 21h
    mov bl, al

    mov dx, offset msg2
    mov ah, 9
    int 21h

    mov ah, 1
    int 21h
    mov bh, al

    cmp bl, bh
    je equal
    ja first_greater

    mov dx, offset msg4
    mov ah, 9
    int 21h
    jmp exit

first_greater:
    mov dx, offset msg3
    mov ah, 9
    int 21h
    jmp exit

equal:
    mov dx, offset msg5
    mov ah, 9
    int 21h

exit:
    mov ah, 4Ch
    int 21h

main endp
end main