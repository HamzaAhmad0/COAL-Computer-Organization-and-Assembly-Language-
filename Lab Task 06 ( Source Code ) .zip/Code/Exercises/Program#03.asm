org 100h

mov cx, 5
mov dx, 48        ; ASCII of '0'

label1:
    mov ah, 2
    int 21h
    add dx, 2
    loop label1

ret