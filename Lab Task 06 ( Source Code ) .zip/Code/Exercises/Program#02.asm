org 100h

mov cx, 10
mov dx, 57        ; ASCII of '9'

label1:
    mov ah, 2
    int 21h
    dec dx
    loop label1

ret