org 100h

mov cx, 10

label1:
    mov dl, 'a'
    mov ah, 2
    int 21h

    dec cx
    jnz label1

ret