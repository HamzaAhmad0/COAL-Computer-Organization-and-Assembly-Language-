.model small
.stack 100h
.data
    msg1 db 13,10,"Enter one character: $"
    msg2 db 13,10,"Digit$"
    msg3 db 13,10,"Not a digit$"

.code
main proc
    mov ax, @data
    mov ds, ax

    mov dx, offset msg1
    mov ah, 9
    int 21h

    mov ah, 1
    int 21h

    cmp al, '0'
    jb not_digit

    cmp al, '9'
    ja not_digit

    mov dx, offset msg2
    mov ah, 9
    int 21h
    jmp exit

not_digit:
    mov dx, offset msg3
    mov ah, 9
    int 21h

exit:
    mov ah, 4Ch
    int 21h

main endp
end main