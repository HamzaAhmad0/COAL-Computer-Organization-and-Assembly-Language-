org 100h

mov cx, 26
mov dx, 97        ; ASCII of 'a'

label1:
    mov ah, 2
    int 21h
    inc dx
    loop label1

ret