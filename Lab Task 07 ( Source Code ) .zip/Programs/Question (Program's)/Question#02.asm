
.model tiny
.code
org 100h

main proc
    mov ah, 9
    lea dx, prompt1
    int 21h

    mov ah, 1
    int 21h
    sub al, 30h
    mov bl, al

    mov ah, 9
    lea dx, prompt2
    int 21h

    mov ah, 1
    int 21h
    sub al, 30h

    mov cl, al
    mov dl, 13
    mov ah, 2
    int 21h
    mov dl, 10
    int 21h

    mov al, bl
    sub al, cl
    add al, 30h

    mov dl, al
    mov ah, 2
    int 21h

    mov ah, 4Ch
    int 21h
main endp

prompt1 db 'Enter first digit (0-9): $'
prompt2 db 13, 10, 'Enter second digit (0-9): $'
end main
