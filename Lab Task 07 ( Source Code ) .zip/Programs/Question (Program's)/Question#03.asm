
.model tiny
.code
org 100h

main proc
    mov ah, 9
    lea dx, prompt
    int 21h

    mov ah, 1
    int 21h

    sub al, 20h
    mov bl, al

    mov ah, 9
    lea dx, message
    int 21h

    mov dl, bl
    mov ah, 2
    int 21h

    mov ah, 4Ch
    int 21h
main endp

prompt  db 'Enter a lowercase letter: $'
message db 13, 10, 'Uppercase letter: $'
end main
